<?php
    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    $type = "news";

    if(!isset($_GET["action"])) ContentNotFound(true);
    if(isset($_GET["type"])) $type = $_GET["type"];

    function getFullArticlePath($articlePath, $type) {
        if(!file_exists("../content/articles/" . $type . "/" . $articlePath . "/content.json") &&
        !file_exists("../content/articles/" . $type . "/" . $articlePath . ".json"))
            ContentNotFound(true);

        return "../content/articles/" . $type . "/" . $articlePath;
    }

    switch($_GET["action"]) {
        case "get":
            if(!isset($_GET["path"])) break;

            $path = getFullArticlePath($_GET["path"], $type);

            if($type != "news") return PrintJsonOutput(
                array(
                    content => json_decode(file_get_contents($path . ".json")),
                ),
                true
            );

            $content = file_get_contents($path . "/content.json");
            $preview = NULL;

            if(file_exists($path . "/preview.jpg"))
                $preview = GetServerAddress() . "/api/image.php?parent=" . $_GET["path"];

            return PrintJsonOutput(
                array(
                    content => json_decode($content),
                    preview => $preview,
                ),
                true
            );
    }

    ContentNotFound(true);
?>