<?php

$_ROOT = "../../";

require_once($_ROOT . 'libs/Cors.php');
require_once($_ROOT . 'libs/Utils.php');

require_once "classes/MaterialsWorker.php";
require_once "classes/FilesWorker.php";

UseCorsHeaders();

global $materialType;
$materialType = isset($_POST["Material-Type"]) ? $_POST["Material-Type"] : "0";

$offset = $_POST["Materials-Offset"] || null;
$length = $_POST["Materials-Count"] || null;

$materialsWorker = new MaterialsWorker($_ROOT);

