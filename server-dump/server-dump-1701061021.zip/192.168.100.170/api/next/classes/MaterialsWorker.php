<?php


/**
 * Класс для быстрого доступа и
 * сортировки материалов сайта
 */
class MaterialsWorker {
    /**
     * @var FilesWorker Переменная-контейнер для класса работы
     * с файловой подсистемой
     */
    private $filesWorker;

    /**
     * @var string Переменная, содержащая информацию о ссылке
     * на коренвой каталог
     */
    private $root;

    public function __construct($root)
    {
        $this->root = $root . "/";
        $this->filesWorker = new FilesWorker($root);
    }

    /**
     * @param int $offset
     * @param int $length
     * @return array|false
     */
    public function fetchMaterialsList (int $offset = null, int $length = null) {
        global $materialType;
        $materialPath = $materialType == "0" ? "news" : ($materialType == "1" ? "document" : "pages");

        $filesList = $this->filesWorker->readFilesList("content/articles/" . $materialPath . "/");
        return array_slice($filesList, $offset, $length);
    }
}