<?php


class APIWorker
{
    public function __construct ()
    {

    }

    public function makeAPIOutput (bool $success, $content)
    {
        return [
            "success" => $success,
            "meta" => $content
        ];
    }

    public function makeJsonOutput (bool $success, $content)
    {
        return $this->makeAPIOutput($success, json_encode($content, JSON_PRETTY_PRINT + JSON_UNESCAPED_SLASHES
            + JSON_UNESCAPED_UNICODE));
    }
}