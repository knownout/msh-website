<?php


/**
 * Класс для работы с файловой подсистемой
 */
class FilesWorker {
    /**
     * @var string ссылка на корневой каталог
     */
    private $root;

    public function __construct($root)
    {
        $this->root = $root;
    }

    /**
     * Метод для получения списка файлов и/или папок из
     * определенногй директории
     * @param string $directory ссылка на просматриваемую директорию
     * @param bool $use_root переключатель использования переменной $root
     * @param string $callback функция фильтрации результата
     * @return array|false
     */
    public function readFilesList (string $directory, bool $use_root = true, string $callback = "is_dir") {
        $root = $this->root;
        if(!$use_root) $root = "";

        $rawObjectsList = glob($root . $directory . "*");
        return array_filter($rawObjectsList, $callback);
    }
}