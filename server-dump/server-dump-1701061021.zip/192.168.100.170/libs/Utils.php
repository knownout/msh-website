<?php

    function ContentNotFound ($json = false) {
        if($json === true)
            PrintJsonOutput(array( reason => "404 Not found" ), false);
        else
            header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");

        exit;
    }

    function GetLatestDirectory ($path) {
        $latest_ctime = 0;
        $latest_name = '';

        $files = glob($path);
        foreach($files as $file)
        {
                if (is_file($file) && filectime($file) > $latest_ctime)
                {
                        $latest_ctime = filectime($file);
                        $latest_filename = $file;
                }
        }

        return basename($latest_filename);
    }

    function JsonOutput ($data, $success = true) {
        return json_encode(
            array(
                success => $success,
                meta => $data
            ),
            JSON_UNESCAPED_UNICODE +
            JSON_PRETTY_PRINT +
            JSON_UNESCAPED_SLASHES
        );
    }

    function PrintJsonOutput ($data, $success = true) {
        header("Content-Type: application/json; charset=utf-8");
        print_r(JsonOutput($data, $success));
    }

    function GetServerAddress () {
        $http = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === 'on' ? "https" : "http");
        $server = isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : $_SERVER["SERVER_NAME"];

        return $http . "://" . $server;
    }

    function ErasePreviousTemp ($dir) {
        if(!file_exists($dir)) return;

        $it = new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS);
        $files = new RecursiveIteratorIterator($it,
                    RecursiveIteratorIterator::CHILD_FIRST);
        foreach($files as $file) {
            if ($file->isDir()){
                rmdir($file->getRealPath());
            } else {
                unlink($file->getRealPath());
            }
        }
        rmdir($dir);
        return;
    }

?>