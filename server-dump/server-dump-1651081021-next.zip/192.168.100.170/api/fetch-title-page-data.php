<?php

    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    $config = json_decode(file_get_contents("../config.json"));
    $mainArticleName = $config->articles->mainArticleName;

    $articlesList = array_map(basename, array_filter(glob("../content/articles/news/*"), "is_dir"));
    $articlesCountOnTitlePage = $config->articles->articlesCountOnTitlePage;

    $articlesToDisplay = array_diff(array_slice($articlesList, 0, $articlesCountOnTitlePage, true), array($mainArticleName));

    $latestInfoContent = GetLatestDirectory("../content/articles/info/*");

    PrintJsonOutput(
        array(
            main_article => $mainArticleName,
            articles => array_values($articlesToDisplay),
            info => pathinfo($latestInfoContent, PATHINFO_FILENAME)
        )
    )
?>