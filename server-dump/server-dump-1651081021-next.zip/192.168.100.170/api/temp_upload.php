<?php

    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    function guidv4($data)
    {
        assert(strlen($data) == 16);

        $data[6] = chr(ord($data[6]) & 0x0f | 0x40); // set version to 0100
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80); // set bits 6-7 to 10

        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }


    if(!isset($_POST["token"]) || !isset($_POST["user"])) ContentNotFound();
    if(!isset($_FILES)) ContentNotFound();

    $userFile = '../content/accounts/' . $_POST["user"] . '.json';
    if(!file_exists($userFile)) ContentNotFound();

    $userToken = (json_decode(file_get_contents($userFile)))->token;
    if(!isset($userToken)) ContentNotFound();


    if($_POST["token"] != $userToken) ContentNotFound();

    $temp_dir = '../content/temp/' . $_POST["user"] . '_' . $_POST["token"];
    ErasePreviousTemp($temp_dir);
    mkdir($temp_dir);

    $target = guidv4(openssl_random_pseudo_bytes(16));
    move_uploaded_file($_FILES["file"]["tmp_name"], $temp_dir . "/" . $target . ".jpg");

    $req = GetServerAddress() . "/api/image.php?temp=true&token=" . $_POST["user"] . '_' . $_POST["token"] . "&file=" . $target;

    return PrintJsonOutput(array(fileName => $req));

?>