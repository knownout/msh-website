<?php


class WorkerFactory
{
    /**
     * @var string ссылка на корневой каталог
     */
    protected $root;

    protected function __construct ($root)
    {
        $this->root = $root;
    }
}