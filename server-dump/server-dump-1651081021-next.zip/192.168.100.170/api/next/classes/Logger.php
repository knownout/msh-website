<?php

require_once "FilesWorker.php";

class Logger
{
    private $root;
    private $logFileLocation = "/content/LOGFILE";

    private $filesWorker;

    private $userLogin;
    private $userToken;

    public function __construct ($root, $userLogin, $userToken)
    {
        $this->root = $root;
        $this->filesWorker = new FilesWorker($root);

        $this->userToken = $userToken;
        $this->userLogin = $userLogin;
    }

    public function Log (string $action, $target = null, $targetType = null, $uid = null) {
        $date = date("d.M.Y h:i:s A");
        $logString = "{$date} [{$this->userLogin} as {$this->userToken}] do {{$action}}";

        if($target) $logString .= " on {{$target}}";
        if($target && $targetType) $logString .= " of type {{$targetType}}";

        if($uid) $logString .= " for {{$uid}}";

        $this->filesWorker->addFileContent($this->logFileLocation, $logString);
    }
}