<?php

require_once "classes/APIWorker.php";
require_once "classes/ImagesWorker.php";

$imagesWorker = new ImagesWorker($_SERVER["DOCUMENT_ROOT"]);
$apiWorker = new APIWorker();

$materialType = isset($_GET["Material-Type"]) ? $_GET["Material-Type"] : "0";

$materialUID = $_GET["Material-UID"];
$imageName = $_GET["Material-Image"];

if(!$materialUID) $apiWorker->returnException("UID key not provided");

$result = true;
if($imageName) $result = $imagesWorker->renderImage($materialType, $materialUID, $imageName);
else $result = $imagesWorker->renderPreviewImage($materialType, $materialUID);

if(!$result) header($_SERVER["SERVER_PROTOCOL"] . " 404 Not Found");