<?php

require_once "types/Actions.php";

require_once "classes/FilesWorker.php";
require_once "classes/APIWorker.php";
require_once "classes/MaterialsWorker.php";
require_once "classes/AccountsWorker.php";
require_once "classes/Logger.php";

global $HostLocation;
$HostLocation = "{$_SERVER["REQUEST_SCHEME"]}://{$_SERVER["SERVER_NAME"]}/";

$accountsWorker = new AccountsWorker($_SERVER["DOCUMENT_ROOT"]);
$materialsWorker = new MaterialsWorker($_SERVER["DOCUMENT_ROOT"]);
$filesWorker = new FilesWorker($_SERVER["DOCUMENT_ROOT"]);
$apiWorker = new APIWorker();

$apiWorker->useCORSHeaders();

$materialType = isset($_POST["Material-Type"]) ? $_POST["Material-Type"] : "0";
$materialUID = $_POST["Material-UID"];

$targetType = $materialType == "0" ? TargetType::MaterialsListNews :
    ($materialType == 1 ? TargetType::MaterialsListDocuments : TargetType::MaterialsListPages);

$userLogin = $_POST["User-Login"];
$userToken = $_POST["User-Token"];

if(!$userLogin) $apiWorker->returnException("User login not provided");
if(!$userToken) $apiWorker->returnException("User api token not provided");

if(!$accountsWorker->verifyAccountToken($userLogin, $userToken))
    $apiWorker->returnException("Invalid user token");

$logger = new Logger($_SERVER["DOCUMENT_ROOT"], $userLogin, $userToken);

$materialsWorker->fetchMaterialsList($materialType);
switch ($_POST["Data-Action"])
{
    case Action::MATERIAL:
        if(!$materialUID) $apiWorker->returnException("Material UID not provided");
        $material = $materialsWorker->readMaterialData($materialType, $materialUID);

        if(!$material) $apiWorker->returnException("Invalid material data file");
        else $apiWorker->returnJsonOutput(true, $material);
        break;

    case Action::CREATE:
        $uid = $apiWorker->generateUID();
        if($materialsWorker->materialExist($uid)) $apiWorker->returnException("Material exist");

        $logger->Log(Action::CREATE, Target::Material, $targetType, $uid);

        $result = $materialsWorker->createEmptyMaterial($materialType, $uid);
        if(!$result) $apiWorker->returnException("Creation failure");

        $apiWorker->returnJsonOutput(true, $uid);
        break;

    case Action::GET:
        $targetType = $materialType == "0" ? TargetType::MaterialsListNews :
            ($materialType == 1 ? TargetType::MaterialsListDocuments : TargetType::MaterialsListPages);

        $logger->Log(Action::GET, Target::MaterialsList, $targetType);

        $offset = intval($_POST["Materials-Offset"]);
        $length = intval($_POST["Materials-Count"]);

        $materialsList = $materialsWorker->fetchMaterialsList($materialType, $offset, $length);

        $materialPath = $materialsWorker->convertMaterialType($materialType, true);

        $resultingList = [
            "current" => [],
            "deferred" => []
        ];

        foreach ($materialsList as $materialUID) {
            $materialSuffix = "/content.json";
            if($materialType == "1") $materialSuffix = ".json";

            $materialRawData = $filesWorker->readFileContent($materialPath . $materialUID . $materialSuffix);
            if(!$materialRawData) {
                $apiWorker->returnException("Invalid material data file");
                continue;
            }

            $materialData = json_decode($materialRawData);

            if(intval($materialData->time) > 0) {
                if (intval($materialData->time) < time() * 1000)
                    array_push($resultingList["current"], $materialUID);
                else array_push($resultingList["deferred"], $materialUID);
            }
        }

        $apiWorker->returnJsonOutput(true, $resultingList);
        break;

    case Action::REMOVE:
        if(!$materialUID) $apiWorker->returnException("Material UID not provided");
        if(!$materialsWorker->materialExist($materialUID))
            $apiWorker->returnException();

        $materialsWorker->removeMaterial($materialType, $materialUID);

        $apiWorker->returnJsonOutput(true, "Removed");
        break;

    case Action::UPDATE:
        if(!$materialUID) $apiWorker->returnException("Material UID not provided");

        if(!$materialsWorker->materialExist($materialUID))
            $apiWorker->returnException("Material not exist");

        $materialData = $_POST["Update::Material-Data"];
        $filesList = $_POST["Update::Files-List"];

        if(!$materialData) $apiWorker->returnException("New material data not provided");
        if($materialType == "1") {
            $filesWorker->setFileContent($materialPath . $materialUID . ".json", $materialData);
            $apiWorker->returnJsonOutput(true, $materialUID);
            break;
        }

        if(!$filesList) $apiWorker->returnException("Files list not provided");

        $filesList = json_decode($filesList);

        $materialPath = $materialsWorker->convertMaterialType($materialType);

        $logger->Log(Action::UPDATE, Target::Material, $targetType, $materialUID);

        $filesWorker->cleanFolderFiles($materialPath . "/images");
        $filesWorker->setFileContent($materialPath . $materialUID . "/content.json", $materialData);

        foreach ($filesList as $fileName) {
            if(!isset($_FILES[$fileName])) continue;
            $file = $_FILES[$fileName];

            $filesWorker->moveUploadedFile($file, $materialPath . $materialUID);
        }

        if($materialType == "0") {
            $previewPath = $_SERVER["DOCUMENT_ROOT"] . $materialPath . $materialUID . "/preview.jpg";
            if(file_exists($previewPath)) unlink($previewPath);

            if(array_key_exists("preview", $filesList))
                $filesWorker->moveUploadedFile($filesList["preview"], $previewPath, true);
        }

        $apiWorker->returnJsonOutput(true, $materialUID);
        break;

    default:
        $apiWorker->returnException();
        break;
}