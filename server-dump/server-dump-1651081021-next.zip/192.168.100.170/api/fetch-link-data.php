<?php

    require_once('../libs/OpenGraph.php');
    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    function fetchLink ($link) {
        $success = 0;
        $data = array();

        try {
            $graph = OpenGraph::fetch($link);
            $success = true;

            $data = array(
                image => array( url => $graph->__get("image") ),
                description => $graph->__get("description"),
                title => $graph->__get("title")
            );
        } catch (Error $e) {
            $success = false;
            $data = array( reason => "Link fetching failure" );
        }

        return array($data, $success);
    }

    if(isset($_GET["link"])) {
        $content = fetchLink($_GET["link"]);
        PrintJsonOutput($content[0], $content[1]);
    }

?>