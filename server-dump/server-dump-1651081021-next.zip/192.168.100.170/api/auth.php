<?php

        require_once('../libs/Cors.php');
        require_once('../libs/Utils.php');
        UseCorsHeaders();

        if(isset($_GET["login"]) && isset($_GET["hash"])) {
            $login = $_GET["login"];
            $hash = $_GET["hash"];

            $accountsPath = "../content/accounts/";
            if(!file_exists($accountsPath . $login . ".json")) ContentNotFound(true);

            $accountData = json_decode(file_get_contents($accountsPath . $login . ".json"));

            if($hash !== $accountData->passHash) ContentNotFound(true);

            $temp_dir = '../content/temp/' . $login . '_' . $accountData->token;
            ErasePreviousTemp($temp_dir);

            PrintJsonOutput(array(
                fullName => $accountData->fullName,
                accountLevel => $accountData->accountLevel,
                token => $accountData->token,
                login => $login
            ), true);
        }

?>