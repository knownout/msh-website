<?php

    require_once('../libs/OpenGraph.php');
    require_once('../libs/Cors.php');

    header('Content-Type: application/json; charset=utf-8');

    function fetchLink ($link) {
        $meta = array(
            "success" => 0,
            "meta" => array(
                "title" => NULL,
                "description" => NULL,
                "image" => array(
                    "url" => NULL
                )
            )
        );

        try {
            $graph = OpenGraph::fetch($link);
            $meta["success"] = 1;

            $meta["meta"]["image"]["url"] = $graph->__get("image");
            $meta["meta"]["description"] = $graph->__get("description");
            $meta["meta"]["title"] = $graph->__get("title");
        } catch (Error $e) {
            $meta["success"] = 0;
        }

        return json_encode($meta);
    }

    useCors();
    if(isset($_GET["link"])) {
        print_r(fetchLink($_GET["link"]));
    }

?>