<?php
    include "../libs/Cors.php";
    header('Content-Type: application/json; charset=utf-8');

    function getArticle($articlePath) {
        if(!file_exists("../content/articles" . $articlePath . ".json")) return false;
        return file_get_contents("../content/articles" . $articlePath . ".json");
    }

    if(!isset($_GET["action"])) exit(0);

    switch($_GET["action"]) {
        case "get":
            if(!isset($_GET["path"])) break;
            print_r(getArticle($_GET["path"]));
            break;
    }

    useCors();
?>