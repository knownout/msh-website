<?php
    include "cors.php";

    function handleGetRequests () {
        if(isset($_GET["read"]) && isset($_GET["section"])) {
            $read_file = $_GET["read"];
            $read_section = $_GET["section"];
            $read_folder = "data/";

            switch($read_file) {
                case "configuration":
                    $content = json_decode(file_get_contents($read_folder . "configuration.json"), true);

                    if ($content[$read_section]) return json_encode($content[$read_section]);
                    else return NULL;
                    break;

                default:
                    return NULL;
            }
        }

        http_response_code(403);
        return NULL;
    }

    cors();
    echo handleGetRequests();
?>