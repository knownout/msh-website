<?php

require_once "FilesWorker.php";

class AccountsWorker
{
    private $accountsStorage;
    private $filesWorker;

    private $accountsList = [];
    private $accountsDataList = [];

    public function __construct ($root = "")
    {
        $this->accountsStorage = $root . "/content/accounts/";
        $this->filesWorker = new FilesWorker($root);

        $this->accountsList = $this->filesWorker->readFilesList(
            $this->accountsStorage, false, "is_file"
        );

        $this->accountsDataList = $this->readAccountsData();
    }

    private function readAccountsData ()
    {
        $accountsData = [];

        foreach ($this->accountsList as $value)
        {
            $content = json_decode($this->filesWorker->readFileContent($value), false, 512,
                JSON_OBJECT_AS_ARRAY);

            $accountsData[$content->userLogin] = $content;
        }

        return $accountsData;
    }

    public function userAccountExist (string $userLogin)
    {
        return array_key_exists($userLogin, $this->accountsDataList);
    }

    public function verifyAccountHash (string $userLogin, string $passwordHash) {
        if(!$this->userAccountExist($userLogin)) return false;

        return $this->accountsDataList[$userLogin]->passHash === $passwordHash;
    }

    public function verifyAccountToken (string $userLogin, string $userToken) {
        if(!$this->userAccountExist($userLogin)) return false;

        return $this->accountsDataList[$userLogin]->token === $userToken;
    }
}