<?php

require_once "WorkerFactory.php";
require_once "MaterialsWorker.php";

class ImagesWorker extends WorkerFactory
{
    private $materialsWorker;
    public const ExecutorPath = "api/next/images-worker.php";

    public function __construct ($root)
    {
        parent::__construct($root);
        $this->materialsWorker = new MaterialsWorker($root);
    }

    public function renderImage (string $materialType, string $materialUID, string $image)
    {
        $materialPath = $this->materialsWorker->readContentPath($materialType, $materialUID, true)
            . "/images/";

        $imageFile = $materialPath . $image . ".jpg";
        return self::renderImageFile($imageFile);
    }

    public function renderPreviewImage (string $materialType, string $materialUID)
    {
        $materialPath = $this->materialsWorker->readContentPath($materialType, $materialUID, true);
        $image = $materialPath . "/preview.jpg";

        return self::renderImageFile($image);
    }

    private function renderImageFile ($filePath)
    {
        if(!file_exists($filePath)) return false;

        header("Content-Type: image/jpg");
        header("Content-Length: " . filesize($filePath));
        readfile($filePath);

        return true;
    }
}