<?php


class Action
{
    public const GET = "GET";
    public const MATERIAL = "MATERIAL";
    public const REMOVE = "REMOVE";
    public const UPDATE = "UPDATE";
    public const CREATE = "CREATE";
    public const TAGLIST = "TAGLIST";
    public const PREVIEW = "PREVIEW";
    public const TAGLISTLENGTH = "TAGLISTLENGTH";
}

class Target
{
    public const Material = "material";
    public const MaterialsList = "materialsList";
}

class TargetType
{
    public const MaterialsListNews = "news";
    public const MaterialsListDocuments = "documents";
    public const MaterialsListPages = "pages";
}