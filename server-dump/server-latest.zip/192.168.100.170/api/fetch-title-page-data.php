<?php

    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');

    UseCorsHeaders();

    $config = json_decode(file_get_contents("../config.json"));

    $filesList = array_filter(glob("../content/articles/news/*"), "is_dir");

    usort($filesList, function ($x, $y) {
        $suffix = "/content.json";

        $dataX = json_decode(file_get_contents($x . $suffix));
        $dataY = json_decode(file_get_contents($y . $suffix));

        $timeX = $dataX->time;
        $timeY = $dataY->time;

        return $timeX < $timeY;
    });

    $articlesList = array_map("basename", $filesList);
    $mainArticleName = $articlesList[0];

    $articlesCountOnTitlePage = $config->articles->articlesCountOnTitlePage;

    $articlesToDisplay = array_diff(array_slice($articlesList, 0, $articlesCountOnTitlePage, true), array($mainArticleName));

    $latestInfoContent = GetLatestDirectory("../content/articles/info/*");

    PrintJsonOutput(
        array(
            "main_article" => $mainArticleName,
            "articles" => array_values($articlesToDisplay),
            "info" => pathinfo($latestInfoContent, PATHINFO_FILENAME)
        )
    )
?>