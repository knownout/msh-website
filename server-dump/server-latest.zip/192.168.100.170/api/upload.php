<?php

    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    $title = $_POST["title"];
    $preview = NULL;
    $content = $_POST["content"];
    $imagesList = array();

    foreach ($_FILES as $key => $file) {
        if($key == "preview") $preview = $file;

        if(strpos($key, "image-") !== false)
            array_push($imagesList, $key);
    }

    var_dump($preview);
    var_dump($imagesList);

    mkdir("../content/articles/news/" . $title);

    $contentFile = fopen("../content/articles/news/" . $title . "/content.json", "w");
    fwrite($contentFile, $content);
    fclose($contentFile);

    mkdir("../content/articles/news/" . $title . "/images/");

    if($preview !== NULL) move_uploaded_file($preview["tmp_name"], "../content/articles/news/" . $title . "/preview.jpg");
    foreach ($imagesList as $image) {
        move_uploaded_file($_FILES[$image]["tmp_name"], "../content/articles/news/" . $title . "/images/" . $_FILES[$image]["name"] . ".jpg");
    }
?>