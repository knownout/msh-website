<?php

    require_once('../libs/Cors.php');
    require_once('../libs/Utils.php');
    UseCorsHeaders();

    $type = "news";

    if(isset($_GET["temp"]) && $_GET["temp"] == "true") {
        $path = $_GET["token"];
        $name = $_GET["file"];

        if(!file_exists("../content/temp/" . $path . "/" . $name . ".jpg")) ContentNotFound();
        $name = "../content/temp/" . $path . "/" . $name . ".jpg";
    } else {
        if(!isset($_GET["parent"])) ContentNotFound();
        $parent = $_GET["parent"];
        $serverPath = "../content/articles/" . $type . "/";

        if(!file_exists($serverPath . $parent)) ContentNotFound();
        if(!isset($_GET["index"]))
            $name = $serverPath . $parent . "/preview.jpg";
        else
            $name = $serverPath . $parent . "/images/" . $_GET["index"] . ".jpg";

        if(!file_exists($name)) ContentNotFound();
    }


    header("Content-Type: image/jpg");
    header("Content-Length: " . filesize($name));
    readfile($name);
    exit;
?>