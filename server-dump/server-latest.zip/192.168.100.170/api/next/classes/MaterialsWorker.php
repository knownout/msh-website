<?php

require_once "FilesWorker.php";
require_once "ImagesWorker.php";

/**
 * Класс для быстрого доступа и
 * сортировки материалов сайта
 */
class MaterialsWorker
{
    /**
     * @var FilesWorker Переменная-контейнер для класса работы
     * с файловой подсистемой
     */
    private $filesWorker;

    /**
     * @var string Переменная, содержащая информацию о ссылке
     * на коренвой каталог
     */
    private $root;

    /**
     * @var array Контейнер для всех материалов сайта, полученных
     * через метод fetchMaterialsList
     */
    public $materialsList = [];

    public function __construct ($root)
    {
        $this->root = $root . "/";
        $this->filesWorker = new FilesWorker($root);
    }

    public function convertMaterialType (int $materialType, bool $useRoot = false)
    {
        $path = $materialType == "0" ? "news" : ($materialType == "1" ? "documents" : "pages");
        $str = "content/articles/" . $path . "/";

        if ($useRoot) $str = $this->root . "content/articles/" . $path . "/";
        return $str;
    }

    public function readContentPath (int $materialType, string $uid, bool $pathOnly = false)
    {
        $containerSuffix = "/content.json";
        if ($materialType != "0") $containerSuffix = ".json";

        $result = $this->root . self::convertMaterialType($materialType)
            . $uid;

        if (!$pathOnly) $result .= $containerSuffix;
        return $result;
    }

    /**
     * Метод для получения списка определенного типа материалов
     *
     * @param int $materialType тип материала (0, 1, 2)
     * @param bool $directory
     * @param int|null $offset отступ от начала списка
     * @param int|null $length количество возвращаемых элементов
     * @return array массив с UID материалов
     */
    public function fetchMaterialsList (int $materialType, $directory = true, int $offset = null, int $length = null)
    {
        $filesList = $this->filesWorker->readFilesList(self::convertMaterialType($materialType),
            true, $directory ? "is_dir" : "is_file");

        global $_directory;
        $_directory = $directory;

        usort($filesList, function ($x, $y) {
            global $_directory;
            $suffix = $_directory == true ? "/content.json" : ".json";

            $dataX = json_decode(file_get_contents(substr($x, -5) == ".json" ? $x : $x . $suffix));
            $dataY = json_decode(file_get_contents(substr($y, -5) == ".json" ? $y : $y . $suffix));

            $timeX = $dataX->time;
            $timeY = $dataY->time;

            return $timeX < $timeY;
        });

        $filesList = array_map("basename", $filesList);

        $this->materialsList = array_slice(
            $filesList,
            $offset == 0 ? null : intval($offset),
            $length == 0 ? null : intval($length)
        );

        return $this->materialsList;
    }

    /**
     * Метод проверки, существует ли уже материал с заданным UID
     *
     * @param string $uid
     * @return bool
     */
    public function materialExist (string $uid)
    {
        return in_array(str_replace(".json", "", $uid), $this->materialsList);
    }

    public function createEmptyMaterial (int $materialType, string $uid)
    {
        if (self::materialExist($uid))
            return false;

        $materialPath = self::readContentPath($materialType, $uid, true);

        $materialContentData = [
            "title" => "EMPTY",
            "time" => 0,
            "blocks" => []
        ];

        if ($materialType == "1")
        {
            file_put_contents($materialPath . ".json", json_encode($materialContentData));
            return true;
        }

        mkdir($materialPath);
        mkdir($materialPath . "/images");

        file_put_contents($materialPath . "/content.json", json_encode($materialContentData));
        return true;
    }

    public function readMaterialData (int $materialType, string $uid)
    {
        self::fetchMaterialsList($materialType, $materialType != "0" ? false : true);
        if (!in_array(str_replace(".json", "", $uid), array_map(function ($e) {
            return str_replace(".json", "", $e); }, $this->materialsList)))
            return null;

        $contentFile = self::readContentPath($materialType, $uid);

        global $HostLocation;

        $preview = null;
        if ($materialType == "0") {
            $previewPath = self::readContentPath($materialType, $uid, true)
                . "/preview.jpg";


            if(file_exists($previewPath)) $preview = $HostLocation
                . ImagesWorker::ExecutorPath
                . "?Material-UID={$uid}&Material-Type={$materialType}";
        }

        return [
            "content" => json_decode($this->filesWorker->readFileContent($contentFile)),
            "uid" => $uid,
            "preview" => $preview
        ];
    }

    public function removeMaterial (int $materialType, string $uid)
    {
        $path = self::readContentPath($materialType, $uid, true);
        $this->filesWorker->recursiveFolderCleanup($path);

        rmdir($path);
    }
}