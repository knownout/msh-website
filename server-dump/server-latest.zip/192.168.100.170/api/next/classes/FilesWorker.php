<?php

require_once "WorkerFactory.php";

/**
 * Класс для работы с файловой подсистемой
 */
class FilesWorker extends WorkerFactory
{


    public function __construct ($root)
    {
        parent::__construct($root);
    }

    /**
     * Метод для получения списка файлов и/или папок из
     * определенногй директории
     * @param string $directory ссылка на просматриваемую директорию
     * @param bool $useRoot переключатель использования переменной $root
     * @param mixed $callback функция фильтрации результата
     * @return array
     */
    public function readFilesList (string $directory, bool $useRoot = true, $callback = "is_dir")
    {
        $root = $this->root . "/";
        if (!$useRoot) $root = "";

        $rawObjectsList = glob($root . $directory . "*");

        if ($callback == null) return $rawObjectsList;
        else return array_filter($rawObjectsList, $callback);
    }

    /**
     * @param string $path
     * @return bool|false|string
     */
    public function readFileContent (string $path)
    {
        if (!is_file($path)) return false;

        return file_get_contents($path);
    }

    public function addFileContent (string $path, string $content, bool $newLine = true)
    {
        if (!is_file($this->root . $path)) return false;
        $totalFileContent = $this->readFileContent($this->root . $path);
        if ($newLine) $totalFileContent .= "\n";

        $totalFileContent .= $content;

        return $this->setFileContent($path, $totalFileContent);
    }

    public function setFileContent (string $path, string $content)
    {
        if (!is_file($this->root . $path)) return false;

        file_put_contents($this->root . $path, $content);
        return true;
    }

    public function cleanFolderFiles ($path)
    {
        $files = self::readFilesList($path, true, null);
        foreach ($files as $file)
            unlink($file);
    }

    public function moveUploadedFile (array $file, string $materialPath, $absolutePath = false)
    {
        $targetFile = $this->root . $materialPath . "/images/" . $file["name"] . ".jpg";
        if ($absolutePath) $targetFile = $materialPath;

        move_uploaded_file($file["tmp_name"], $targetFile);
    }

    public function recursiveFolderCleanup (string $directory)
    {
        $it = new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS);
        $files = new RecursiveIteratorIterator($it,
            RecursiveIteratorIterator::CHILD_FIRST);

        foreach ($files as $file)
        {
            if ($file->isDir()) rmdir($file->getRealPath());
            else  unlink($file->getRealPath());

        }
    }
}